const express = require('express');
const app = express();
const songRoute = express.Router();
let filessystem = require('fs')
const  jwt  =  require('jsonwebtoken');
const SECRET_KEY = "secretkey23456";


var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "mydb"
});





let multer = require('multer'),
  router = express.Router();

// Multer File upload settings
const DIR = '../src/assets/base/';


const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    
    if(file.fieldname == "video"){
      
      if (!filessystem.existsSync(DIR + req.body.name + "/video")){
        filessystem.mkdirSync(DIR + req.body.name + "/video", {recursive:true});
        cb(null, DIR + req.body.name + "/video");
      }
      else{
        cb(null, DIR + req.body.name + "/video");
      }
      
    }
    
    
  },
  filename: (req, file, cb) => {
    const fileName = file.originalname;
    cb(null, fileName)
  }
});

// Multer Mime Type Validation
var upload = multer({
  storage: storage
  // limits: {
  //   fileSize: 1024 * 1024 * 5
  // },
  // fileFilter: (req, file, cb) => {
  //   if (file.mimetype == "image/png" || file.mimetype == "image/jpg" || file.mimetype == "image/jpeg") {
  //     cb(null, true);
  //   } else {
  //     cb(null, false);
  //     return cb(new Error('Only .png, .jpg and .jpeg format allowed!'));
  //   }
  // }
});



songRoute.post('/upload-video', upload.single('video'), (req, res, next) => {
  console.log(req)
  const url = req.protocol + '://' + req.get('host')
  const user = new User({
    _id: new mongoose.Types.ObjectId(),
    name: req.body.name,
    avatar: url + '/uploads/' + req.file.filename
  });
  user.save().then(result => {
    console.log(result);
    res.status(201).json({
      message: "User registered successfully!",
      userCreated: {
        _id: result._id,
        name: result.name,
        avatar: result.avatar
      }
    })
  }).catch(err => {
    console.log(err),
      res.status(500).json({
        error: err
      });
  })
  // FileModel.create(req.body, (error, data) => {
  //   if (error) {
  //     return next(error)
  //   } else {
  //     console.log(data)
  //     res.json(data)
  //   }
  // })
});






//////////////////////////////////
// Add Song
songRoute.route('/phone_numbers').post((req, res, next) => {
  
});

// Get all songs
songRoute.route('/phone_numbers').get((req, res) => {
  con.connect(function(err) {
  
  con.query("SELECT * FROM phone_numbers_data", function (err, result) {
    if (err) {
      
    } else {
      res.json(result)
    }
    console.log(result);
  });


});

})

// Get single song
songRoute.route('/phone_numbers/:id').get((req, res) => {
  
})


// Search songs1

songRoute.route('/search_phone_numbers/:region/:district').get((req, res) => {
  let text = req.params.region;
  console.log(text)
  con.connect(function(err) {
  
  con.query("SELECT * FROM customers WHERE address LIKE '%" + text + "%' OR name LIKE '%" + text + "%'", function (err, result) {
    if (err) {
      return next(err)
    } else {
      res.json(result)
    }
    console.log(result);
  });


});

})

// Search songs2
songRoute.route('/search_phone_numbers/:text').get((req, res) => {
  let text = req.params.text;
  console.log(text)
  con.connect(function(err) {
  
  con.query("SELECT * FROM customers WHERE address LIKE '%" + text + "%' OR name LIKE '%" + text + "%'", function (err, result) {
    if (err) {
      return next(err)
    } else {
      res.json(result)
    }
    console.log(result);
  });


});

})

// Update song
songRoute.route('/phone_numbers/:id').put((req, res, next) => {
  
})

// Delete song
songRoute.route('/phone_numbers/:id').delete((req, res, next) => {
  
})



//////////////////////////////////
// User Portfolio




// Add Song
songRoute.route('/newuser').post((req, res, next) => {
  
  let username = req.body.login
  let email = req.body.email
  let password = req.body.password
  con.connect(function(err) {
  
  con.query("SELECT * FROM portfolio_users WHERE username = '%" + username + "%'", function (err, result1) {
    if (err) {
      
    } else {
      console.log(result1.length)
      if(result1.length == 0){
        con.query("SELECT * FROM portfolio_users WHERE email = '%" + email + "%'", function (err, result2) {
          if (err) {
            
          } else {
            if(result2.length == 0){
              var sql = "INSERT INTO portfolio_users (username, email, password) VALUES ('" + username + "', '" + email + "', '" + password + "')";
              con.query(sql, function (err, result3) {
                if (err) {
                  console.log(result3);
                  res.json({"success":false})
                }
                else{
                  console.log(result3);
                  const expiresIn = 24*60*60;
                  const accessToken = jwt.sign({id: result3.insertId}, SECRET_KEY, {
                      expiresIn:  expiresIn
                  });
                  
                  res.json({"success": true, "id": result3.insertId, "token": accessToken, "expires_in":  expiresIn})
                  
                }
                
              });
            }
          }
          // console.log(result);
        });
      }
    }
    // console.log(result);
  });
  });


});

// Get all songs
songRoute.route('/users').get((req, res) => {
  con.connect(function(err) {
  
  con.query("SELECT * FROM portfolio_users", function (err, result) {
    if (err) {
      return next(err)
    } else {
      res.json(result)
    }
    console.log(result);
  });


});

})

// Get single song
songRoute.route('/users/:id').get((req, res) => {
  let id = req.params.id;
  con.connect(function(err) {
  
  con.query("SELECT * FROM portfolio_users WHERE id = '" + Number(id) + "'", function (err, result) {
    if (err) {
      
    } else {
      res.json(result)
    }
    console.log(result);
  });


});


})


// Search songs1

songRoute.route('/search_users_username').post((req, res, next) => {
  let username = req.body.login;
  let password = req.body.password;
  
  let row = ""

  if(username.indexOf("@") !== -1){
    row = "email"
  }
  else{
    row = "username"
  }
  con.connect(function(err) {
  
  con.query("SELECT * FROM portfolio_users WHERE " + row + " = '" + username + "'", function (err, result) {
    if (err) {
      
    } else {
      if(result.length != 0){
        if (password == result[0]["password"]) {
          const expiresIn = 24*60*60;
          const accessToken = jwt.sign({id: result[0]["id"]}, SECRET_KEY, {
              expiresIn:  expiresIn
          });
          
          res.json({"success": true, "id": result[0]["id"], "token": accessToken, "expires_in":  expiresIn})
        }
        else{
          res.json({"success": false})
        }
        
      }
      else{
        res.json({"success": false})
      }
      
    }
    
  });


});

})

// Search email

songRoute.route('/search_users_usernamefilter/:username').get((req, res) => {
  let username = req.params.username;
  
  con.connect(function(err) {
  
  con.query("SELECT * FROM portfolio_users WHERE username = '" + username + "'", function (err, result) {
    if (err) {
      
    } else {
      if(result.length != 0){
        res.json({"success": true, "id": result[0]["id"]})        
      }
      else{
        res.json(result)
      }
      
    }
    
  });


});

})

songRoute.route('/search_users_emailfilter/:email').get((req, res) => {
  let email = req.params.email;
  
  con.connect(function(err) {
  
  con.query("SELECT * FROM portfolio_users WHERE email = '" + email + "'", function (err, result) {
    if (err) {
      
    } else {
      if(result.length != 0){
        res.json({"success": true, "id": result[0]["id"]})
      }
      else{
        res.json(result)
      }
    }
  });
});

})


// Update song
songRoute.route('/users/:id').put((req, res, next) => {
  let id = req.params.id;
  let phone_number = req.body.phone_number
  let region = req.body.region
  let district = req.body.district
  let portfolio = req.body.portfolio

  console.log(district)
  
  con.connect(function(err) {
  var sql = "UPDATE portfolio_users SET phone_number = \"" + phone_number + "\", region = \"" + region + "\", district = \"" + district + "\" WHERE id = '" + id + "'";
  con.query(sql, function (err, result) {
    if (err){
      res.json({"success": false})
    }
    else{
      res.json({"success": true})
    }
    
  });
});
})

// Delete song
songRoute.route('/users/:id').delete((req, res, next) => {
  
})



module.exports = songRoute;