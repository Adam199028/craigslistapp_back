
let express = require('express'),
  path = require('path'),
  cors = require('cors'),
  bodyParser = require('body-parser');

const songRoute = require('./routes/routes.route')

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
  extended: false
}));
app.use(cors());


app.use('/uploads', express.static('uploads'));

// RESTful API root
app.use('/api', songRoute)

// PORT
const port = process.env.PORT || 3000;

app.listen(port, () => {
  console.log('PORT Connected on: ' + port)
})


// error handler
app.use(function (err, req, res, next) {
  console.error(err.message);
  if (!err.statusCode) err.statusCode = 500;
  res.status(err.statusCode).send(err.message);
});